import logging

logger = logging.getLogger('shrub')
